
public interface MyInteger_itf extends SharedObject_itf {
	public void incr();
	public int getInt();
}