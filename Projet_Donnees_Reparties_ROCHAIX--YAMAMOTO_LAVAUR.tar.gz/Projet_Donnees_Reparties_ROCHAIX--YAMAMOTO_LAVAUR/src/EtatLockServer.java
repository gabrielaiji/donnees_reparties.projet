public enum EtatLockServer {NL, RL, WL}
