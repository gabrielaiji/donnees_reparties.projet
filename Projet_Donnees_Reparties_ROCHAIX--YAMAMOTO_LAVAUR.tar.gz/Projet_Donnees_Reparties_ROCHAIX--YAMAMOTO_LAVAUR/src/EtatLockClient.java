public enum EtatLockClient {
    NL, RLC, WLC, RLT, WLT, RLT_WLC
}
