public interface ServerObject_itf {
	public Object lock_read(Client_itf client);
	public Object lock_write(Client_itf client);
}
